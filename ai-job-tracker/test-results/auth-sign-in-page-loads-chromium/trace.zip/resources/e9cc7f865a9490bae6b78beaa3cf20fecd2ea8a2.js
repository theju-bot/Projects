(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__06.-pfn._.css","static/chunks/node_modules_@tanstack_query-devtools_build_0_pysku._.js","static/chunks/node_modules_000gwq3._.js","static/chunks/_0es2m7w._.js"],
    source: "dynamic"
});
